# llama.cpp/example/run

The purpose of this example is to demonstrate a minimal usage of llama.cpp for running models.

```bash
./llama-run Meta-Llama-3.1-8B-Instruct.gguf
...
