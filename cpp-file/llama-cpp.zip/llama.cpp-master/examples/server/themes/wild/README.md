# LLaMA.cpp Server Wild Theme

Simple tweaks to the UI. To use simply run server with `--path=themes/wild`

![image](wild.png)
